from aiogram import Bot
from aiogram.types import BotCommand, BotCommandScopeChat, BotCommandScopeAllPrivateChats, BotCommandScopeAllGroupChats


PRIVATE_COMMANDS = [
    BotCommand(command="start", description="🏠 Главное меню"),
    BotCommand(command="help", description="❓ Помощь"),
    BotCommand(command="admin", description="⚙️ Панель администратора"),
    BotCommand(command="config", description="⚙️ Конфигурация бота"),
    BotCommand(command="logs", description="📋 Последние логи"),
    BotCommand(command="buy", description="⭐ Пополнить баланс"),
    BotCommand(command="admins", description="👑 Список администраторов"),
    BotCommand(command="setdev", description="👑 Назначить разработчика"),
    BotCommand(command="setbotadmin", description="🛡️ Назначить админа бота"),
    BotCommand(command="removeadmin", description="🗑 Снять админа"),
    BotCommand(command="setadmin", description="👤 Назначить админа чата"),
    BotCommand(command="removechatadmin", description="🗑 Снять админа чата"),
    BotCommand(command="chatadmins", description="👤 Список админов чатов"),
]

GROUP_COMMANDS = [
    BotCommand(command="mute", description="🔇 Замутить пользователя"),
    BotCommand(command="unmute", description="🔊 Снять мут"),
    BotCommand(command="ban", description="🚫 Забанить пользователя"),
    BotCommand(command="unban", description="✅ Разбанить"),
    BotCommand(command="kick", description="👢 Кикнуть"),
    BotCommand(command="warn", description="⚠️ Выдать варн"),
    BotCommand(command="warns", description="📋 Проверить варны"),
    BotCommand(command="warnlist", description="📋 Список варнов"),
    BotCommand(command="clearwarns", description="🧹 Очистить варны"),
    BotCommand(command="clear", description="🗑 Удалить сообщения"),
    BotCommand(command="del", description="🗑 Удалить одно сообщение"),
    BotCommand(command="pin", description="📌 Закрепить"),
    BotCommand(command="unpin", description="📌 Открепить"),
    BotCommand(command="lock", description="🔒 Закрыть чат"),
    BotCommand(command="unlock", description="🔓 Открыть чат"),
    BotCommand(command="slowmode", description="🐢 Установить slowmode"),
    BotCommand(command="mute_all", description="🔇 Замутить всех"),
    BotCommand(command="unmute_all", description="🔊 Размутить всех"),
    BotCommand(command="kickme", description="👢 Покинуть чат"),
    BotCommand(command="admins", description="👑 Список админов группы"),
    BotCommand(command="settitle", description="✏️ Сменить название"),
    BotCommand(command="setdescription", description="✏️ Сменить описание"),
    BotCommand(command="leave", description="👋 Бот покидает чат"),
    BotCommand(command="banlist", description="🚫 Список забаненных"),
    BotCommand(command="info", description="👤 Инфо о пользователе"),
    BotCommand(command="addbanword", description="🤬 Добавить слово в бан"),
    BotCommand(command="delbanword", description="🤬 Убрать слово из бана"),
    BotCommand(command="banwords", description="📋 Список запрещённых слов"),
    BotCommand(command="addtrigger", description="🎯 Добавить триггер"),
    BotCommand(command="deltrigger", description="🗑 Удалить триггер"),
    BotCommand(command="triggers", description="📋 Список триггеров"),
    BotCommand(command="giveaway", description="🎁 Создать розыгрыш"),
    BotCommand(command="giveaways", description="🎁 Активные розыгрыши"),
    BotCommand(command="cancelgiveaway", description="❌ Отменить розыгрыш"),
    BotCommand(command="schedule", description="⏰ Отложенное сообщение"),
    BotCommand(command="recurring_add", description="📅 Регулярный пост"),
    BotCommand(command="addfeed", description="📡 RSS-подписка"),
    BotCommand(command="feeds", description="📡 Мои RSS-ленты"),
    BotCommand(command="stat", description="📊 Статистика в чате"),
    BotCommand(command="top", description="🏆 Топ пользователей"),
    BotCommand(command="mystat", description="📊 Моя статистика"),
    BotCommand(command="report", description="🚨 Пожаловаться"),
    BotCommand(command="mod", description="🛡️ Назначить модератора"),
    BotCommand(command="unmod", description="🛡️ Снять модератора"),
    BotCommand(command="mods", description="📋 Список модераторов"),
]


async def set_bot_commands(bot: Bot):
    try:
        await bot.set_my_commands(PRIVATE_COMMANDS, scope=BotCommandScopeAllPrivateChats())
    except Exception as e:
        logging.getLogger(__name__).error(f"Private commands: {e}")

    try:
        await bot.set_my_commands(GROUP_COMMANDS, scope=BotCommandScopeAllGroupChats())
    except Exception as e:
        logging.getLogger(__name__).error(f"Group commands: {e}")
