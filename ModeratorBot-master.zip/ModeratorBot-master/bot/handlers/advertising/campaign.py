from datetime import datetime, timezone
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from bot.database.requests import (
    create_campaign_ad, update_campaign_ad, get_campaign_ad,
    get_campaign_ads_by_status, delete_campaign_ad, get_campaign_logs,
)
from bot.filters.admin import IsAdminFilter
from bot.filters.chat_type import IsPrivateFilter
from bot.keyboards.inline import (
    campaign_panel_kb, campaign_list_kb, campaign_view_kb,
    campaign_edit_kb, campaign_skip_kb, back_kb,
)
from bot.utils.texts import (
    CAMPAIGN_PANEL_TEXT, CAMPAIGN_LIST_HEADER, CAMPAIGN_LIST_ITEM,
    NO_CAMPAIGNS, CAMPAIGN_VIEW_TEXT, CAMPAIGN_CREATED,
    CAMPAIGN_PAUSED, CAMPAIGN_RESUMED, CAMPAIGN_DELETED,
    CAMPAIGN_LOG_HEADER, CAMPAIGN_LOG_ITEM, CAMPAIGN_NO_LOGS,
    FSM_CAMPAIGN_TITLE, FSM_CAMPAIGN_DESC, FSM_CAMPAIGN_PHOTO,
    FSM_CAMPAIGN_BTN_TEXT, FSM_CAMPAIGN_BTN_URL, FSM_CAMPAIGN_INTERVAL,
    FSM_CAMPAIGN_MAX_POSTS, CAMPAIGN_EDIT_CHOICE, CAMPAIGN_EDITED,
    FSM_CAMPAIGN_CHAT_ID,
)

router = Router()


class CampaignStates(StatesGroup):
    chat_id = State()
    title = State()
    description = State()
    photo = State()
    button_text = State()
    button_url = State()
    interval = State()
    max_posts = State()


def format_interval(seconds: int | None) -> str:
    if not seconds or seconds <= 0:
        return "однократно"
    hours = seconds // 3600
    if hours < 24:
        return f"каждые {hours} ч."
    days = hours // 24
    if hours % 24 == 0:
        return f"каждые {days} дн."
    return f"каждые {days} дн. {hours % 24} ч."


def format_status(status: str) -> str:
    return {"active": "✅ Активна", "paused": "⏸ Приостановлена", "completed": "✅ Завершена", "cancelled": "🚫 Отменена"}.get(status, status)


@router.callback_query(F.data == "campaign_panel", IsAdminFilter())
async def campaign_panel(callback: CallbackQuery):
    await callback.message.edit_text(CAMPAIGN_PANEL_TEXT, reply_markup=campaign_panel_kb())
    await callback.answer()


@router.callback_query(F.data == "campaign_create", IsAdminFilter())
async def campaign_create_start(callback: CallbackQuery, state: FSMContext):
    await state.set_state(CampaignStates.chat_id)
    await callback.message.edit_text(FSM_CAMPAIGN_CHAT_ID, reply_markup=back_kb("campaign_panel"))
    await callback.answer()


@router.message(CampaignStates.chat_id, IsPrivateFilter())
async def campaign_get_chat_id(message: Message, state: FSMContext):
    try:
        chat_id = int(message.text.strip())
    except ValueError:
        return await message.answer("❌ Введите числовой ID чата (например, -1001234567890).")
    await state.update_data(chat_id=chat_id)
    await state.set_state(CampaignStates.title)
    await message.answer(FSM_CAMPAIGN_TITLE.format(chat_id=chat_id), reply_markup=back_kb("campaign_cancel"))


@router.callback_query(F.data == "campaign_cancel", IsAdminFilter())
async def campaign_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text(CAMPAIGN_PANEL_TEXT, reply_markup=campaign_panel_kb())
    await callback.answer()


@router.message(CampaignStates.title, IsPrivateFilter())
async def campaign_get_title(message: Message, state: FSMContext):
    title = message.text.strip()
    if not title or len(title) > 256:
        return await message.answer("❌ Название должно быть от 1 до 256 символов.")
    await state.update_data(title=title)
    await state.set_state(CampaignStates.description)
    await message.answer(FSM_CAMPAIGN_DESC.format(title=title), reply_markup=back_kb("campaign_cancel"))


@router.message(CampaignStates.description, IsPrivateFilter())
async def campaign_get_desc(message: Message, state: FSMContext):
    description = message.text or message.caption or ""
    await state.update_data(description=description, has_media=bool(message.photo or message.video or message.document))
    if message.photo:
        await state.update_data(photo=message.photo[-1].file_id)
        await state.set_state(CampaignStates.button_text)
        return await message.answer(FSM_CAMPAIGN_BTN_TEXT, reply_markup=back_kb("campaign_cancel"))
    await state.set_state(CampaignStates.photo)
    await message.answer(FSM_CAMPAIGN_PHOTO, reply_markup=campaign_skip_kb("campaign_skip_photo"))


@router.callback_query(F.data == "campaign_skip_photo", CampaignStates.photo)
async def campaign_skip_photo(callback: CallbackQuery, state: FSMContext):
    await state.set_state(CampaignStates.button_text)
    await callback.message.edit_text(FSM_CAMPAIGN_BTN_TEXT, reply_markup=back_kb("campaign_cancel"))
    await callback.answer()


@router.message(CampaignStates.photo, IsPrivateFilter())
async def campaign_get_photo(message: Message, state: FSMContext):
    if message.photo:
        await state.update_data(photo=message.photo[-1].file_id)
    await state.set_state(CampaignStates.button_text)
    await message.answer(FSM_CAMPAIGN_BTN_TEXT, reply_markup=back_kb("campaign_cancel"))


@router.message(CampaignStates.button_text, IsPrivateFilter())
async def campaign_get_btn_text(message: Message, state: FSMContext):
    btn_text = message.text.strip()
    if not btn_text or len(btn_text) > 128:
        return await message.answer("❌ Текст кнопки должен быть от 1 до 128 символов.")
    await state.update_data(button_text=btn_text)
    await state.set_state(CampaignStates.button_url)
    await message.answer(FSM_CAMPAIGN_BTN_URL, reply_markup=back_kb("campaign_cancel"))


@router.message(CampaignStates.button_url, IsPrivateFilter())
async def campaign_get_btn_url(message: Message, state: FSMContext):
    url = message.text.strip()
    if not url.startswith(("https://", "http://")):
        return await message.answer("❌ Ссылка должна начинаться с https://")
    if len(url) > 1024:
        return await message.answer("❌ Ссылка слишком длинная.")
    await state.update_data(button_url=url)
    await state.set_state(CampaignStates.interval)
    await message.answer(FSM_CAMPAIGN_INTERVAL, reply_markup=back_kb("campaign_cancel"))


@router.message(CampaignStates.interval, IsPrivateFilter())
async def campaign_get_interval(message: Message, state: FSMContext):
    try:
        hours = float(message.text.strip().replace(",", "."))
        if hours < 0:
            raise ValueError
        interval_seconds = int(hours * 3600) if hours > 0 else 0
    except ValueError:
        return await message.answer("❌ Введите число часов (например, 1, 6, 24). 0 — однократно.")
    await state.update_data(interval_seconds=interval_seconds)
    await state.set_state(CampaignStates.max_posts)
    await message.answer(FSM_CAMPAIGN_MAX_POSTS, reply_markup=back_kb("campaign_cancel"))


@router.message(CampaignStates.max_posts, IsPrivateFilter())
async def campaign_get_max_posts(message: Message, state: FSMContext):
    try:
        max_posts = int(message.text.strip())
        if max_posts < 0:
            raise ValueError
    except ValueError:
        return await message.answer("❌ Введите целое число (0 — безлимит).")
    data = await state.get_data()
    data["max_posts"] = max_posts

    user = message.from_user
    ad = await create_campaign_ad(
        chat_id=data.get("chat_id", 0),
        creator_id=user.id,
        title=data["title"],
        description=data.get("description", ""),
        photo=data.get("photo"),
        button_text=data.get("button_text"),
        button_url=data.get("button_url"),
        interval_seconds=data.get("interval_seconds", 0),
        max_posts=max_posts,
    )

    await state.clear()
    interval_str = format_interval(data.get("interval_seconds", 0))
    await message.answer(
        CAMPAIGN_CREATED.format(title=data["title"], interval=interval_str, max_posts=max_posts if max_posts else "∞"),
        reply_markup=campaign_view_kb(ad.id, ad.status),
    )


@router.callback_query(F.data.startswith("campaign_view:"), IsAdminFilter())
async def campaign_view(callback: CallbackQuery):
    ad_id = int(callback.data.split(":")[1])
    ad = await get_campaign_ad(ad_id)
    if not ad:
        return await callback.message.edit_text("❌ Кампания не найдена.", reply_markup=back_kb("campaign_list"))
    interval_str = format_interval(ad.interval_seconds)
    await callback.message.edit_text(
        CAMPAIGN_VIEW_TEXT.format(
            title=ad.title,
            description=ad.description or "—",
            button_text=ad.button_text or "—",
            button_url=ad.button_url or "—",
            photo="✅" if ad.photo else "❌",
            interval=interval_str,
            posts_made=ad.posts_made,
            max_posts=ad.max_posts if ad.max_posts else "∞",
            status=format_status(ad.status),
            created_at=ad.created_at.strftime("%d.%m.%Y %H:%M") if ad.created_at else "—",
        ),
        reply_markup=campaign_view_kb(ad.id, ad.status),
    )
    await callback.answer()


@router.callback_query(F.data == "campaign_list", IsAdminFilter())
async def campaign_list(callback: CallbackQuery):
    ads = await get_campaign_ads_by_status("active")
    ads += await get_campaign_ads_by_status("paused")
    ads += await get_campaign_ads_by_status("completed")
    if not ads:
        return await callback.message.edit_text(NO_CAMPAIGNS, reply_markup=back_kb("campaign_panel"))

    lines = [CAMPAIGN_LIST_HEADER]
    for i, ad in enumerate(ads, 1):
        interval_str = format_interval(ad.interval_seconds)
        status_str = format_status(ad.status)
        lines.append(CAMPAIGN_LIST_ITEM.format(
            num=i, title=ad.title[:30], status=status_str,
            posts=ad.posts_made, max_posts=ad.max_posts or "∞",
            interval=interval_str, id=ad.id,
        ))

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=campaign_list_kb(ads),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("campaign_pause:"), IsAdminFilter())
async def campaign_pause(callback: CallbackQuery):
    ad_id = int(callback.data.split(":")[1])
    await update_campaign_ad(ad_id, status="paused")
    ad = await get_campaign_ad(ad_id)
    await callback.message.edit_text(
        CAMPAIGN_PAUSED.format(title=ad.title),
        reply_markup=campaign_view_kb(ad_id, "paused"),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("campaign_resume:"), IsAdminFilter())
async def campaign_resume(callback: CallbackQuery):
    ad_id = int(callback.data.split(":")[1])
    await update_campaign_ad(ad_id, status="active")
    ad = await get_campaign_ad(ad_id)
    await callback.message.edit_text(
        CAMPAIGN_RESUMED.format(title=ad.title),
        reply_markup=campaign_view_kb(ad_id, "active"),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("campaign_delete:"), IsAdminFilter())
async def campaign_delete(callback: CallbackQuery):
    ad_id = int(callback.data.split(":")[1])
    ad = await get_campaign_ad(ad_id)
    if ad:
        title = ad.title
        await delete_campaign_ad(ad_id)
        await callback.message.edit_text(
            CAMPAIGN_DELETED.format(title=title),
            reply_markup=back_kb("campaign_list"),
        )
    else:
        await callback.message.edit_text("❌ Кампания не найдена.", reply_markup=back_kb("campaign_list"))
    await callback.answer()


@router.callback_query(F.data.startswith("campaign_edit:"), IsAdminFilter())
async def campaign_edit_menu(callback: CallbackQuery):
    ad_id = int(callback.data.split(":")[1])
    await callback.message.edit_text(
        CAMPAIGN_EDIT_CHOICE.format(ad_id=ad_id),
        reply_markup=campaign_edit_kb(ad_id),
    )
    await callback.answer()


# ─── Edit sub-items ──────────────────────────────────────────────

class CampaignEditStates(StatesGroup):
    desc = State()
    photo = State()
    btn = State()
    interval = State()


@router.callback_query(F.data.startswith("campaign_edit_desc:"), IsAdminFilter())
async def campaign_edit_desc_start(callback: CallbackQuery, state: FSMContext):
    ad_id = int(callback.data.split(":")[1])
    await state.update_data(edit_ad_id=ad_id)
    await state.set_state(CampaignEditStates.desc)
    await callback.message.edit_text("✏️ Введите новый текст рекламы:", reply_markup=back_kb(f"campaign_edit:{ad_id}"))
    await callback.answer()


@router.message(CampaignEditStates.desc, IsPrivateFilter())
async def campaign_edit_desc_done(message: Message, state: FSMContext):
    data = await state.get_data()
    ad_id = data["edit_ad_id"]
    new_text = message.text or message.caption or ""
    await update_campaign_ad(ad_id, description=new_text)
    await state.clear()
    await message.answer(CAMPAIGN_EDITED, reply_markup=campaign_view_kb(ad_id, "active"))


@router.callback_query(F.data.startswith("campaign_edit_photo:"), IsAdminFilter())
async def campaign_edit_photo_start(callback: CallbackQuery, state: FSMContext):
    ad_id = int(callback.data.split(":")[1])
    await state.update_data(edit_ad_id=ad_id)
    await state.set_state(CampaignEditStates.photo)
    await callback.message.edit_text("✏️ Отправьте новое фото (или нажмите «Пропустить»):",
                                     reply_markup=campaign_skip_kb(f"campaign_edit_photo_skip:{ad_id}"))
    await callback.answer()


@router.callback_query(F.data.startswith("campaign_edit_photo_skip:"), IsAdminFilter())
async def campaign_edit_photo_skip(callback: CallbackQuery, state: FSMContext):
    ad_id = int(callback.data.split(":")[1])
    await state.clear()
    await callback.message.edit_text(CAMPAIGN_EDITED, reply_markup=campaign_view_kb(ad_id, "active"))
    await callback.answer()


@router.message(CampaignEditStates.photo, IsPrivateFilter())
async def campaign_edit_photo_done(message: Message, state: FSMContext):
    data = await state.get_data()
    ad_id = data["edit_ad_id"]
    if message.photo:
        await update_campaign_ad(ad_id, photo=message.photo[-1].file_id)
    await state.clear()
    await message.answer(CAMPAIGN_EDITED, reply_markup=campaign_view_kb(ad_id, "active"))


@router.callback_query(F.data.startswith("campaign_edit_btn:"), IsAdminFilter())
async def campaign_edit_btn_start(callback: CallbackQuery, state: FSMContext):
    ad_id = int(callback.data.split(":")[1])
    await state.update_data(edit_ad_id=ad_id)
    await state.set_state(CampaignEditStates.btn)
    await callback.message.edit_text("✏️ Введите новый текст кнопки и URL через |\n\nПример:\n<code>Перейти | https://example.com</code>",
                                     reply_markup=back_kb(f"campaign_edit:{ad_id}"))
    await callback.answer()


@router.message(CampaignEditStates.btn, IsPrivateFilter())
async def campaign_edit_btn_done(message: Message, state: FSMContext):
    data = await state.get_data()
    ad_id = data["edit_ad_id"]
    text = message.text.strip()
    if "|" in text:
        btn_text, url = text.rsplit("|", 1)
        btn_text = btn_text.strip()
        url = url.strip()
    else:
        btn_text = text
        url = ""
    if not url.startswith(("https://", "http://")):
        return await message.answer("❌ Ссылка должна начинаться с https://")
    await update_campaign_ad(ad_id, button_text=btn_text, button_url=url)
    await state.clear()
    await message.answer(CAMPAIGN_EDITED, reply_markup=campaign_view_kb(ad_id, "active"))


@router.callback_query(F.data.startswith("campaign_edit_interval:"), IsAdminFilter())
async def campaign_edit_interval_start(callback: CallbackQuery, state: FSMContext):
    ad_id = int(callback.data.split(":")[1])
    await state.update_data(edit_ad_id=ad_id)
    await state.set_state(CampaignEditStates.interval)
    await callback.message.edit_text("✏️ Введите новый интервал в часах (0 — однократно):",
                                     reply_markup=back_kb(f"campaign_edit:{ad_id}"))
    await callback.answer()


@router.message(CampaignEditStates.interval, IsPrivateFilter())
async def campaign_edit_interval_done(message: Message, state: FSMContext):
    data = await state.get_data()
    ad_id = data["edit_ad_id"]
    try:
        hours = float(message.text.strip().replace(",", "."))
        if hours < 0:
            raise ValueError
        interval_seconds = int(hours * 3600) if hours > 0 else 0
    except ValueError:
        return await message.answer("❌ Введите число часов.")
    await update_campaign_ad(ad_id, interval_seconds=interval_seconds)
    await state.clear()
    await message.answer(CAMPAIGN_EDITED, reply_markup=campaign_view_kb(ad_id, "active"))


# ─── Logs ────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("campaign_logs:"), IsAdminFilter())
async def campaign_logs(callback: CallbackQuery):
    ad_id = int(callback.data.split(":")[1])
    logs = await get_campaign_logs(ad_id, limit=30)
    if not logs:
        return await callback.message.edit_text(CAMPAIGN_NO_LOGS, reply_markup=back_kb(f"campaign_view:{ad_id}"))

    lines = [CAMPAIGN_LOG_HEADER.format(ad_id=ad_id)]
    for log in logs:
        if log.message_id:
            status = f"✅ msg #{log.message_id}"
        else:
            status = f"❌ {log.error or 'ошибка'}"
        lines.append(CAMPAIGN_LOG_ITEM.format(
            posted_at=log.posted_at.strftime("%d.%m.%Y %H:%M") if log.posted_at else "—",
            status=status,
        ))
    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=back_kb(f"campaign_view:{ad_id}"),
    )
    await callback.answer()
