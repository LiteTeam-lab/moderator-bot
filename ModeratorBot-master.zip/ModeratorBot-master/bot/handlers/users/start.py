from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from bot.loader import config
from bot.keyboards.inline import register_kb, back_kb
from bot.keyboards.reply import main_menu_kb, remove_kb
from bot.utils.texts import START_TEXT, HELP_TEXT, PROFILE_TEXT
from bot.database.requests import get_user, get_warnings_count, get_user_ads

router = Router()


@router.message(Command("config"))
async def cmd_config(message: Message):
    token_masked = config.bot_token[:6] + "..." + config.bot_token[-4:] if len(config.bot_token) > 20 else "❌ НЕ УКАЗАН"
    await message.answer(
        f"<b>⚙️ Конфигурация бота</b>\n\n"
        f"🔑 Токен: <code>{token_masked}</code>\n"
        f"👑 Админы: <code>{config.admin_ids}</code>\n"
        f"🗄 БД: <code>{config.database_url}</code>\n"
        f"⏭ Скип апдейтов: {config.skip_updates}\n\n"
        f"📄 Файл настроек: <code>.env</code>\n"
        f"📝 Лог-файл: <code>bot.log</code>"
    )


@router.message(Command("logs"))
async def cmd_logs(message: Message):
    if message.from_user.id not in config.admin_ids:
        return await message.answer("❌ Нет доступа.")
    import os
    log_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "bot.log")
    if not os.path.isfile(log_path):
        return await message.answer("📭 Лог-файл не найден (пока нет записей).")
    try:
        with open(log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        last_lines = "".join(lines[-30:])
        if len(last_lines) > 3900:
            last_lines = last_lines[-3900:]
        await message.answer(f"<b>📋 Последние логи:</b>\n<code>{last_lines}</code>")
    except Exception as e:
        await message.answer(f"❌ Ошибка: {e}")


@router.message(CommandStart())
async def cmd_start(message: Message, db_user):
    await message.answer(
        START_TEXT,
        reply_markup=register_kb(),
    )


@router.message(Command("help"))
@router.callback_query(F.data == "help")
async def cmd_help(event: Message | CallbackQuery):
    text = HELP_TEXT
    if isinstance(event, CallbackQuery):
        await event.message.edit_text(text, reply_markup=back_kb("start"))
        await event.answer()
    else:
        await event.answer(text)


@router.callback_query(F.data == "start")
async def back_to_start(callback: CallbackQuery):
    await callback.message.edit_text(START_TEXT, reply_markup=register_kb())
    await callback.answer()


@router.callback_query(F.data == "profile")
@router.message(F.text == "👤 Профиль")
async def show_profile(event: Message | CallbackQuery, db_user):
    warns = await get_warnings_count(db_user.id, 0)
    ads = await get_user_ads(db_user.id)
    text = PROFILE_TEXT.format(
        user_id=db_user.id,
        first_name=db_user.first_name or "—",
        username=db_user.username or "—",
        role=db_user.role.value,
        balance=db_user.balance or 0,
        warns=warns,
        ads_count=len(ads),
    )
    if isinstance(event, CallbackQuery):
        await event.message.edit_text(text, reply_markup=back_kb("start"))
        await event.answer()
    else:
        await event.answer(text, reply_markup=register_kb())


@router.message(F.text == "❓ Помощь")
async def help_reply(message: Message):
    await message.answer(HELP_TEXT, reply_markup=register_kb())
