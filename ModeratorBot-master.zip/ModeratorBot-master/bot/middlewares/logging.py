import logging
from datetime import datetime, timezone
from typing import Callable, Dict, Any, Awaitable

from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery

logger = logging.getLogger("bot.actions")


class ActionLogMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[Message | CallbackQuery, Dict[str, Any]], Awaitable[Any]],
        event: Message | CallbackQuery,
        data: Dict[str, Any],
    ) -> Any:
        user = event.from_user
        time_str = datetime.now(timezone.utc).strftime("%H:%M:%S")
        if isinstance(event, Message):
            chat = event.chat
            chat_info = f"{chat.title or 'ЛС'} [{chat.id}]" if chat else "—"
            text = (event.text or event.caption or "[медиа]")[:100]
            logger.info(f"[{time_str}] {user.full_name} (@{user.username or '—'}) в {chat_info}: {text}")
        elif isinstance(event, CallbackQuery):
            logger.info(f"[{time_str}] {user.full_name} (@{user.username or '—'}) нажал: {event.data}")

        return await handler(event, data)
