import asyncio
import logging
import sys
from logging.handlers import RotatingFileHandler

from bot.loader import bot, dp, config
from bot.database.base import init_db, close_db
from bot.handlers import register_handlers
from bot.middlewares.throttle import ThrottlingMiddleware
from bot.middlewares.acl import ACLMiddleware
from bot.middlewares.logging import ActionLogMiddleware
from bot.handlers.advertising.scheduler import start_scheduler
from bot.utils.commands import set_bot_commands

log_format = "%(asctime)s | %(name)-15s | %(levelname)-5s | %(message)s"

logging.basicConfig(level=logging.INFO, format=log_format, stream=sys.stdout)

file_handler = RotatingFileHandler("bot.log", maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8")
file_handler.setFormatter(logging.Formatter(log_format))
logging.getLogger().addHandler(file_handler)

logger = logging.getLogger(__name__)


async def on_startup():
    if not config.bot_token or config.bot_token == "YOUR_BOT_TOKEN_HERE":
        logger.error("BOT_TOKEN не указан в .env! Открой файл .env и вставь токен от @BotFather")
        return

    logger.info("Инициализация базы данных...")
    await init_db()
    logger.info("База данных готова")

    dp.message.middleware(ThrottlingMiddleware())
    dp.callback_query.middleware(ThrottlingMiddleware())
    dp.message.middleware(ACLMiddleware())
    dp.callback_query.middleware(ACLMiddleware())
    dp.message.middleware(ActionLogMiddleware())
    dp.callback_query.middleware(ActionLogMiddleware())

    register_handlers()

    await start_scheduler()
    logger.info("Планировщик запущен (7 задач)")

    if config.admin_ids:
        for admin_id in config.admin_ids:
            try:
                await bot.send_message(admin_id, "✅ <b>Бот запущен и готов к работе!</b>")
            except Exception:
                pass

    me = await bot.me()
    await set_bot_commands(bot)
    logger.info(f"Команды бота зарегистрированы")
    logger.info(f"Бот запущен! @{me.username} [ID: {me.id}]")


async def on_shutdown():
    logger.info("Остановка бота...")
    await close_db()
    await bot.session.close()


async def main():
    await on_startup()
    try:
        await dp.start_polling(
            bot,
            skip_updates=config.skip_updates,
            allowed_updates=["message", "callback_query", "my_chat_member", "chat_member"],
        )
    finally:
        await on_shutdown()


if __name__ == "__main__":
    asyncio.run(main())
